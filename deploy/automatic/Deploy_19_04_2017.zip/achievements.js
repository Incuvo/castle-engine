//use castle
db = db.getSiblingDB('castle');

cur = db.definition.achievements.find();
achievements = cur.toArray();
db.usersProfiles.update({},{$set:{"achievements": achievements}},{multi:true});
db.fightHistory.update({},{$set:{destroyedRoomsList:[]}},{multi: true});

db.usersProfiles.find({}).forEach(function(doc){
//upgradeAchievements
        for(var i = 0; i < doc.castle.roomsList.length; i++) {
            achievementId = '';
            room = doc.castle.roomsList[i];
            predictedProgress = room.roomLevel;
            if (room.roomType == "TREASURY_VAULT") {
		achievementId = "achivMakeIt";
                index = 1;

            } else if (room.roomType == "THRONE") {
		achievementId = "achivFortress";
                index = 0;

            } else if (room.roomType == "EXPLORER") {
		achievementId = "achivBroaden";
                index = 2;

            } else if (room.roomType == "ARMORY") {
		achievementId = "achivFirepower";
                index = 3;

            } else {
		continue;
            }

            if (doc.achievements[index].id == achievementId) {
		if (predictedProgress > doc.achievements[index].currentProgress)
	                doc.achievements[index].currentProgress = predictedProgress;
	    }
            else
                print(achievementId + ' not on index ' + index + ' for user ' + doc.display_name + ' ' + doc.username);
        }

//achivEndless, achivGraysons
	boss = [1,25,34,51,60,74,84,91,99];
	bossId = ["5846750078626b116e014315","58527fd4aee562585d00001f","585285f7aee562585d001052","58528ea8be550bd60f001c7d","5852944d9cb36dd80f006045","5852a18b8c14c61349002aee","5852ab048fecbe114900af4a","5852b4e98c14c6134901876a","5852b7f98fecbe114901ade3"]
        bossProgress = 0;
        for(var j = 0; j < doc.map.length; j++) {
		map = doc.map[j];
//achivGraysons
		if(boss.indexOf(map.locationId) > -1) {
                        //check if boss on slot
			if (bossId.indexOf(map.user.valueOf()) > -1) {
				if (map.defeated) {
					if (doc.achievements[7].id == 'achivGraysons') {
						//if (doc.display_name == 'pako')
						//	print('Found defeated boss on ' + map.locationId);
        	                                doc.achievements[7].currentProgress += 1;
					}
	                                else
                	                        print('achivGraysons not on index 7');
				}
			} else {
				if (doc.achievements[7].id == 'achivGraysons') {
					//if (doc.display_name == 'pako')
					//	print('Found other slot on ' + map.locationId);
					doc.achievements[7].currentProgress += 1;
				}
				else
					print('achivGraysons not on index 7');
			}
		}
//achivEndless
		if (map.defeated)
			if (doc.achievements[6].id == 'achivEndless')
				doc.achievements[6].currentProgress += 1;
			else
				print('achivEndless not on index 6');
	}
//achivEnemy
	if (doc.achievements[9].id == 'achivEnemy')
		doc.achievements[9].currentProgress = doc.trophies;
	else
		print('achivEnemy not on index 9');
//achivLeague
	if (doc.achievements[10].id == 'achivLeague')
		doc.achievements[10].currentProgress = doc.trophies;
	else
		print('achivLeague not on index 10');
//achivVoyager
	if (doc.achievements[12].id == 'achivVoyager')
		doc.achievements[12].currentProgress = doc.trophies;
	else
		print('achivVoyager not on index 12');


	db.usersProfiles.save(doc);
});

