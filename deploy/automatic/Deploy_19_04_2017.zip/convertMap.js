//use castle
db = db.getSiblingDB('castle');

// ids = {
// 	"9": 11,
// 	"11": 9,
// 	"48": 51,
// 	"49": 48,
// 	"50": 49,
// 	"51": 50,
// 	"59": 66,
// 	"62": 69,
// 	"65": 999,
// 	"67": 999,
// 	"68": 999,
// 	"71": 999,
// 	"72": 999,
// 	"73": 68,
// 	"74": 62,
// 	"75": 999,
// 	"76": 999,
// 	"77": 999,
// 	"78": 999
// }
ids = {
    "49": [48],
    "50": [49],
    "57": [51, 50, 57],
    "59": [66, 59],
    "62": [69],
	"65": [-1],
	"67": [-1],
    "68": [-1]
}

db.usersProfiles.find({}).forEach(function(doc){

	changed = false;
	newElements = [];
	for (var key in ids) {
		index = doc.cloud.indexOf(parseInt(key));
		if (index > -1 ) {
			changed = true;
			doc.cloud.splice(index, 1);
			if (ids[key][0] > -1) {
				newElements = newElements.concat(ids[key]);
			}
		}
	}
	if (changed) {
		doc.cloud = doc.cloud.concat(newElements);
		db.usersProfiles.save(doc);
	}
});
