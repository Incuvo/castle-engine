//set database
db = db.getSiblingDB('castle-staging');

switchMap = [
    {"dest" : "player25","src" : "player34"},
    {"dest" : "player34","src" : "player51"},
    {"dest" : "player51","src" : "player60"},
    {"dest" : "player60","src" : "player74"},
    {"dest" : "player74","src" : "player84"},
    {"dest" : "player84","src" : "player91"},
    {"dest" : "player91","src" : "player99"},
    {"dest" : "player99","src" : "player44150"}
];
print("SWITCH STARTED");
for (var i=0; i < switchMap.length; i++) {

//set destination username
    var dest = switchMap[i].dest;
//set source username
    var src = switchMap[i].src;
    var destinationAccount = db.usersProfiles.findOne({username: dest});
    var sourceAccount = db.usersProfiles.findOne({username: src});

    if (destinationAccount && sourceAccount) {
        destinationAccount.username = src;
        sourceAccount.username = dest;

        var tmpPassword = sourceAccount.password;
        var tmpNid = sourceAccount.nid;
        var tmp_id = sourceAccount._id;
        var tmpEmail = sourceAccount.email;

        sourceAccount.password = destinationAccount.password;
        sourceAccount.nid = destinationAccount.nid;
        sourceAccount._id = destinationAccount._id;
        sourceAccount.email = destinationAccount.email;
        sourceAccount.display_name = "Graysons Castle";
        sourceAccount.profileType = "NPC_BOSS";

        destinationAccount.password = tmpPassword;
        destinationAccount.nid = tmpNid;
        destinationAccount._id = tmp_id;
        destinationAccount.email = tmpEmail;
        destinationAccount.display_name = "Graysons Castle";
        destinationAccount.profileType = "NPC_BOSS";

        print("SWITCHED ACCOUNT");
        db.usersProfiles.remove({username: src});
        db.usersProfiles.remove({username: dest});

        print(db.usersProfiles.save(destinationAccount));
        print(db.usersProfiles.save(sourceAccount));

    } else {
        print("Destination or source account not found");
    }

}